<?php

/* programation_circuit/show.html.twig */
class __TwigTemplate_a7f04f047fb7de44bcd9e27ee9821a54a146e99a782212c5f9ae07b921d9da87 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "programation_circuit/show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "programation_circuit/show.html.twig"));

        // line 1
        echo "<!DOCTYPE html>

<title>ProgramationCircuit</title>

";
        // line 5
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <h1>ProgramationCircuit</h1>

    <table class=\"table\">
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["programation_circuit"]) || array_key_exists("programation_circuit", $context) ? $context["programation_circuit"] : (function () { throw new Twig_Error_Runtime('Variable "programation_circuit" does not exist.', 12, $this->source); })()), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>DateDepart</th>
                <td>";
        // line 16
        echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->source, (isset($context["programation_circuit"]) || array_key_exists("programation_circuit", $context) ? $context["programation_circuit"] : (function () { throw new Twig_Error_Runtime('Variable "programation_circuit" does not exist.', 16, $this->source); })()), "dateDepart", array())) ? (twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["programation_circuit"]) || array_key_exists("programation_circuit", $context) ? $context["programation_circuit"] : (function () { throw new Twig_Error_Runtime('Variable "programation_circuit" does not exist.', 16, $this->source); })()), "dateDepart", array()), "Y-m-d H:i:s")) : ("")), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>NombrePersonnes</th>
                <td>";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["programation_circuit"]) || array_key_exists("programation_circuit", $context) ? $context["programation_circuit"] : (function () { throw new Twig_Error_Runtime('Variable "programation_circuit" does not exist.', 20, $this->source); })()), "nombrePersonnes", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Prix</th>
                <td>";
        // line 24
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["programation_circuit"]) || array_key_exists("programation_circuit", $context) ? $context["programation_circuit"] : (function () { throw new Twig_Error_Runtime('Variable "programation_circuit" does not exist.', 24, $this->source); })()), "prix", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <a href=\"";
        // line 29
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("programation_circuit_index");
        echo "\">back to list</a>

    <a href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("programation_circuit_edit", array("id" => twig_get_attribute($this->env, $this->source, (isset($context["programation_circuit"]) || array_key_exists("programation_circuit", $context) ? $context["programation_circuit"] : (function () { throw new Twig_Error_Runtime('Variable "programation_circuit" does not exist.', 31, $this->source); })()), "id", array()))), "html", null, true);
        echo "\">edit</a>

    ";
        // line 33
        echo twig_include($this->env, $context, "programation_circuit/_delete_form.html.twig");
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "programation_circuit/show.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  101 => 33,  96 => 31,  91 => 29,  83 => 24,  76 => 20,  69 => 16,  62 => 12,  54 => 6,  36 => 5,  30 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>

<title>ProgramationCircuit</title>

{% block body %}
    <h1>ProgramationCircuit</h1>

    <table class=\"table\">
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ programation_circuit.id }}</td>
            </tr>
            <tr>
                <th>DateDepart</th>
                <td>{{ programation_circuit.dateDepart ? programation_circuit.dateDepart|date('Y-m-d H:i:s') : '' }}</td>
            </tr>
            <tr>
                <th>NombrePersonnes</th>
                <td>{{ programation_circuit.nombrePersonnes }}</td>
            </tr>
            <tr>
                <th>Prix</th>
                <td>{{ programation_circuit.prix }}</td>
            </tr>
        </tbody>
    </table>

    <a href=\"{{ path('programation_circuit_index') }}\">back to list</a>

    <a href=\"{{ path('programation_circuit_edit', {'id': programation_circuit.id}) }}\">edit</a>

    {{ include('programation_circuit/_delete_form.html.twig') }}
{% endblock %}
", "programation_circuit/show.html.twig", "/mci/ei1619/zribi_no/CSC4101/agvoy-app-03/templates/programation_circuit/show.html.twig");
    }
}
