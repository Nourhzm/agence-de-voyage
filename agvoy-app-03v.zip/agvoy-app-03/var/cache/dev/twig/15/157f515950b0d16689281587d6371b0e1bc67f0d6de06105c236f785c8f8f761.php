<?php

/* backoffice_home/index.html.twig */
class __TwigTemplate_c7086a80907d19c49347e2b5b0e88468a5d08e327e93d1df25631bd88ea05a79 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("baselayout.html.twig", "backoffice_home/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "baselayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "backoffice_home/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "backoffice_home/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Circuits ! ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "
<h1> Circuit index </h1>

    <table class=\"table\">
        <thead>
            <tr>
                <th> Id </th>
                <th> description </th>
                <th> pays Depart </th>
                <th> ville Depart \t</th>
                <th> ville Arrivee </th> 
        <th> duree Circuit </th>
        <th> date </th>
        <th> Prix </th>
                <td> &nbsp;</td>
            </tr>
        </thead>
        <tbody>
        ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["circuits"]) || array_key_exists("circuits", $context) ? $context["circuits"] : (function () { throw new Twig_Error_Runtime('Variable "circuits" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["circuit"]) {
            // line 25
            echo "        ";
            // line 28
            echo "            <tr>
                <td>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "id", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "description", array()), "html", null, true);
            echo " </td>
                <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "paysDepart", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "villeDepart", array()), "html", null, true);
            echo "</td>
                 <td> ";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "villeArrivee", array()), "html", null, true);
            echo "</td>
                 <td> ";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "dureeCircuit", array()), "html", null, true);
            echo "</td>
                 <td>  ";
            // line 35
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["prog"]) || array_key_exists("prog", $context) ? $context["prog"] : (function () { throw new Twig_Error_Runtime('Variable "prog" does not exist.', 35, $this->source); })()), "dateDepart", array()), "Y-m-d H:i:s"), "html", null, true);
            echo "</td>
                 <td> ";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["prog"]) || array_key_exists("prog", $context) ? $context["prog"] : (function () { throw new Twig_Error_Runtime('Variable "prog" does not exist.', 36, $this->source); })()), "prix", array()), "html", null, true);
            echo " </td>
                 <td> <a href=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("circuit_show", array("id" => twig_get_attribute($this->env, $this->source, $context["circuit"], "id", array()))), "html", null, true);
            echo "\"> détails </a> </td>
            </tr>
            
        ";
            // line 43
            echo "          
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['circuit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "        </tbody>
    </table>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "backoffice_home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 45,  139 => 43,  133 => 37,  129 => 36,  125 => 35,  121 => 34,  117 => 33,  113 => 32,  109 => 31,  105 => 30,  101 => 29,  98 => 28,  96 => 25,  92 => 24,  72 => 6,  63 => 5,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'baselayout.html.twig' %}

{% block title %} Circuits ! {% endblock %}

{% block main %}

<h1> Circuit index </h1>

    <table class=\"table\">
        <thead>
            <tr>
                <th> Id </th>
                <th> description </th>
                <th> pays Depart </th>
                <th> ville Depart \t</th>
                <th> ville Arrivee </th> 
        <th> duree Circuit </th>
        <th> date </th>
        <th> Prix </th>
                <td> &nbsp;</td>
            </tr>
        </thead>
        <tbody>
        {% for  circuit in circuits %}
        {# {%  if   circuit.programmations is not empty  %}
          {% for prog in circuit.programmations %}  
          {% if date(prog.dateDepart) > date() %} #}
            <tr>
                <td>{{ circuit.id }}</td>
                <td>{{ circuit.description}} </td>
                <td>{{ circuit.paysDepart }}</td>
                <td>{{ circuit.villeDepart }}</td>
                 <td> {{ circuit.villeArrivee }}</td>
                 <td> {{ circuit.dureeCircuit }}</td>
                 <td>  {{ prog.dateDepart|date('Y-m-d H:i:s')}}</td>
                 <td> {{ prog.prix}} </td>
                 <td> <a href=\"{{ path('circuit_show', {'id': circuit.id}) }}\"> détails </a> </td>
            </tr>
            
        {#}  {% endif %}  
          {% endfor %}  
        {% endif %} #}
          
        {% endfor %}
        </tbody>
    </table>
{% endblock %}", "backoffice_home/index.html.twig", "/mci/ei1619/zribi_no/CSC4101/proj-agvoy/agvoy-app-03/templates/backoffice_home/index.html.twig");
    }
}
