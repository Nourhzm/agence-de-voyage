<?php

/* frontoffice_home/index.html.twig */
class __TwigTemplate_5ae0d5c116c453faff8ed117bc1f64f7ef71825fb5e54365bac15634fcd30515 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("baselayout.html.twig", "frontoffice_home/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "baselayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontoffice_home/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontoffice_home/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Circuits ! ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "
<h1> Circuit index </h1>

    <table class=\"table\">
        <thead>
            <tr>
                <th> Id </th>
                <th> description </th>
                <th> pays Depart </th>
                <th> ville Depart \t</th>
                <th> ville Arrivee </th> 
        <th> duree Circuit </th>
        <th> date </th>
        <th> Prix </th>
                <td> &nbsp;</td>
            </tr>
        </thead>
        <tbody>
        ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["circuits"]) || array_key_exists("circuits", $context) ? $context["circuits"] : (function () { throw new Twig_Error_Runtime('Variable "circuits" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["circuit"]) {
            // line 25
            if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, $context["circuit"], "programmations", array()))) {
                // line 26
                echo "          ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["circuit"], "programmations", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["prog"]) {
                    echo "  
          ";
                    // line 27
                    if ((twig_date_converter($this->env, twig_get_attribute($this->env, $this->source, $context["prog"], "dateDepart", array())) > twig_date_converter($this->env))) {
                        // line 28
                        echo "            <tr>
                <td>";
                        // line 29
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "id", array()), "html", null, true);
                        echo "</td>
                <td>";
                        // line 30
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "description", array()), "html", null, true);
                        echo " </td>
                <td>";
                        // line 31
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "paysDepart", array()), "html", null, true);
                        echo "</td>
                <td>";
                        // line 32
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "villeDepart", array()), "html", null, true);
                        echo "</td>
                 <td> ";
                        // line 33
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "villeArrivee", array()), "html", null, true);
                        echo "</td>
                 <td> ";
                        // line 34
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["circuit"], "dureeCircuit", array()), "html", null, true);
                        echo "</td>
                 <td>  ";
                        // line 35
                        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["prog"], "dateDepart", array()), "Y-m-d H:i:s"), "html", null, true);
                        echo "</td>
                 <td> ";
                        // line 36
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["prog"], "prix", array()), "html", null, true);
                        echo " </td>
                 <td> <a href=\"";
                        // line 37
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("circuit_show", array("id" => twig_get_attribute($this->env, $this->source, $context["circuit"], "id", array()))), "html", null, true);
                        echo "\"> détails </a> </td>
                ";
                        // line 38
                        if (twig_in_filter(twig_get_attribute($this->env, $this->source, $context["prog"], "id", array()), (isset($context["likes"]) || array_key_exists("likes", $context) ? $context["likes"] : (function () { throw new Twig_Error_Runtime('Variable "likes" does not exist.', 38, $this->source); })()))) {
                            // line 39
                            echo "                 <td> <a href=\"";
                            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("circuit_likes", array("id" => twig_get_attribute($this->env, $this->source, $context["prog"], "id", array()))), "html", null, true);
                            echo "\" > dislike </a> </td>
                 ";
                        } else {
                            // line 41
                            echo "                       <td> <a href=\"";
                            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("circuit_likes", array("id" => twig_get_attribute($this->env, $this->source, $context["prog"], "id", array()))), "html", null, true);
                            echo "\" > like </a> </td>
                  ";
                        }
                        // line 43
                        echo "             
            </tr>
            
          ";
                    }
                    // line 46
                    echo "  
          ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['prog'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 47
                echo "  
        ";
            }
            // line 49
            echo "          
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['circuit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "        </tbody>
    </table>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "frontoffice_home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  184 => 51,  177 => 49,  173 => 47,  166 => 46,  160 => 43,  154 => 41,  148 => 39,  146 => 38,  142 => 37,  138 => 36,  134 => 35,  130 => 34,  126 => 33,  122 => 32,  118 => 31,  114 => 30,  110 => 29,  107 => 28,  105 => 27,  98 => 26,  96 => 25,  92 => 24,  72 => 6,  63 => 5,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'baselayout.html.twig' %}

{% block title %} Circuits ! {% endblock %}

{% block main %}

<h1> Circuit index </h1>

    <table class=\"table\">
        <thead>
            <tr>
                <th> Id </th>
                <th> description </th>
                <th> pays Depart </th>
                <th> ville Depart \t</th>
                <th> ville Arrivee </th> 
        <th> duree Circuit </th>
        <th> date </th>
        <th> Prix </th>
                <td> &nbsp;</td>
            </tr>
        </thead>
        <tbody>
        {% for  circuit in circuits %}
{%  if   circuit.programmations is not empty  %}
          {% for prog in circuit.programmations %}  
          {% if date(prog.dateDepart) > date() %}
            <tr>
                <td>{{ circuit.id }}</td>
                <td>{{ circuit.description}} </td>
                <td>{{ circuit.paysDepart }}</td>
                <td>{{ circuit.villeDepart }}</td>
                 <td> {{ circuit.villeArrivee }}</td>
                 <td> {{ circuit.dureeCircuit }}</td>
                 <td>  {{ prog.dateDepart|date('Y-m-d H:i:s')}}</td>
                 <td> {{ prog.prix}} </td>
                 <td> <a href=\"{{ path('circuit_show', {'id': circuit.id}) }}\"> détails </a> </td>
                {%  if prog.id in likes %}
                 <td> <a href=\"{{ path('circuit_likes', {'id': prog.id}) }}\" > dislike </a> </td>
                 {% else %}
                       <td> <a href=\"{{ path('circuit_likes', {'id': prog.id}) }}\" > like </a> </td>
                  {% endif %}
             
            </tr>
            
          {% endif %}  
          {% endfor %}  
        {% endif %}
          
        {% endfor %}
        </tbody>
    </table>
{% endblock %}", "frontoffice_home/index.html.twig", "/mci/ei1619/zribi_no/CSC4101/proj-agvoy/agvoy-app-03/templates/frontoffice_home/index.html.twig");
    }
}
