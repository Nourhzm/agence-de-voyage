<?php

/* baselayout.html.twig */
class __TwigTemplate_d09c84b1ee2f408f29678daaac3208538d5553f0233cf61d2e70f76663fc2d29 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'custompage_style' => array($this, 'block_custompage_style'),
            'body' => array($this, 'block_body'),
            'menu' => array($this, 'block_menu'),
            'alerts' => array($this, 'block_alerts'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
            'custompage_script' => array($this, 'block_custompage_script'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "baselayout.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "baselayout.html.twig"));

        // line 21
        echo "<!DOCTYPE HTML>
<html>
<head>
<meta charset=\"utf-8\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>";
        // line 28
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
";
        // line 29
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 44
        echo "</head>
<body>
\t";
        // line 46
        $this->displayBlock('body', $context, $blocks);
        // line 161
        echo " ";
        // line 162
        echo "</body>
";
        // line 163
        $this->displayBlock('javascripts', $context, $blocks);
        // line 168
        echo " ";
        // line 169
        $this->displayBlock('custompage_script', $context, $blocks);
        // line 171
        echo "
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 28
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Application Agence Voyage ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 29
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 30
        echo "<!-- Bootstrap -->
<link rel=\"stylesheet\"\thref=\"/fonts/css/bootstrap-darkly.css\">

";
        // line 33
        $this->displayBlock('custompage_style', $context, $blocks);
        // line 36
        echo "<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
          <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
          <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
        <![endif]-->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 33
    public function block_custompage_style($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "custompage_style"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "custompage_style"));

        // line 34
        echo "<link href=\"/fonts/css/styles.css\" rel=\"stylesheet\">
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 46
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        echo " ";
        // line 47
        echo "             <header>
\t\t";
        // line 48
        $this->displayBlock('menu', $context, $blocks);
        // line 54
        echo " ";
        // line 55
        echo "             </header>

";
        // line 57
        $this->displayBlock('alerts', $context, $blocks);
        // line 71
        echo " ";
        // line 72
        echo "

\t<div style=\"min-height: 90%\" class=\"container\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-12\">
\t\t\t\t<div>
\t\t\t\t\tAgence Voyage !
\t\t\t\t</div>

\t\t\t</div>
\t\t</div>

\t\t<div class=\"container body-container\">
<main>
\t\t\t";
        // line 86
        $this->displayBlock('main', $context, $blocks);
        // line 94
        echo " ";
        // line 95
        echo "</main>
\t\t</div> <!-- /.body-container -->
\t\t";
        // line 97
        $this->displayBlock('footer', $context, $blocks);
        // line 158
        echo "
\t</div>
\t<!-- /.container -->
\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 48
    public function block_menu($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 49
        echo "\t\t\t\t";
        // line 50
        echo "\t\t\t\t<nav class=\"navbar navbar-expand-md navbar-dark fixed-top bg-light\">
\t\t\t\t\t";
        // line 51
        echo $this->extensions['Knp\Menu\Twig\MenuExtension']->render("main", array("currentClass" => "active"));
        echo "
\t\t\t\t\t";
        // line 52
        echo $this->extensions['Knp\Menu\Twig\MenuExtension']->render("user", array("currentClass" => "active"));
        echo "
\t\t\t\t</nav>
\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 57
    public function block_alerts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "alerts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "alerts"));

        // line 58
        echo " ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 58, $this->source); })()), "session", array()), "flashBag", array()), "all", array()));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 59
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 60
                echo "        ";
                if (($context["type"] == "error")) {
                    echo " ";
                    $context["type"] = "danger";
                    echo " ";
                }
                // line 61
                echo "        ";
                if (($context["type"] == "message")) {
                    echo " ";
                    $context["type"] = "info";
                    echo " ";
                }
                // line 62
                echo "        <div class=\"alert alert-";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo " alert-dismissible\" role=\"alert\">
            <button type=\"button\" class=\"close\" data-dismiss=\"alert\">
                <span aria-hidden=\"true\">&times;</span>
                <span class=\"sr-only\">Close</span>
            </button>
            <p>";
                // line 67
                echo $context["message"];
                echo "</p>
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 86
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 87
        echo "\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t<p>
\t\t\t\t\t\t<i> Welcome  </i>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 97
    public function block_footer($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 98
        echo "\t
<footer class=\"page-footer font-small blue pt-4\">

    <!-- Footer Links -->
    <div class=\"container-fluid text-center text-md-left\">

    
      <div class=\"row\">

        <div class=\"col-md-6 mt-md-0 mt-3\">

          <!-- Content -->
          <h5 class=\"text-uppercase\"> Bonne visite </h5>
          <p>Ici vous trouverez les meilleures voyages avec les meilleurs prix.</p>

        </div>
       

        <hr class=\"clearfix w-100 d-md-none pb-3\">

     
        <div class=\"col-md-3 mb-md-0 mb-3\">

            <h5 class=\"text-uppercase\"> Contactez-nous</h5>

            <ul class=\"list-unstyled\">
              <li>
                <p>(+33) 06 25 25 14 74</p>
              </li>
              <li>
                <p>5, Rue Charles Fourier,91000, EVRY</p>
              </li>
             
            </ul>

          </div>
      
      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class=\"footer-copyright text-center py-3\"> © 2018 Copyright:
    
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->

\t\t<!--  <div class=\"row\">
\t\t\t<div class=\"col-md-12\">
\t\t\t\t<footer>
\t\t\t\t\t<p > Bonne Visite </p>
\t\t\t\t</footer>
\t\t\t</div>
\t\t</div> -->
\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 163
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 164
        echo "<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script\tsrc=\"../../assets/js/jquery-3.3.1.js\"></script>
<script src=\"../../assets/js/popper.js\"></script>
<script\tsrc=\"../../assets/js/bootstrap.js\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 169
    public function block_custompage_script($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "custompage_script"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "custompage_script"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "baselayout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  438 => 169,  424 => 164,  415 => 163,  346 => 98,  337 => 97,  320 => 87,  311 => 86,  290 => 67,  281 => 62,  274 => 61,  267 => 60,  262 => 59,  257 => 58,  248 => 57,  235 => 52,  231 => 51,  228 => 50,  226 => 49,  217 => 48,  204 => 158,  202 => 97,  198 => 95,  196 => 94,  194 => 86,  178 => 72,  176 => 71,  174 => 57,  170 => 55,  168 => 54,  166 => 48,  163 => 47,  153 => 46,  142 => 34,  133 => 33,  117 => 36,  115 => 33,  110 => 30,  101 => 29,  83 => 28,  71 => 171,  69 => 169,  67 => 168,  65 => 163,  62 => 162,  60 => 161,  58 => 46,  54 => 44,  52 => 29,  48 => 28,  39 => 21,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# templates/baselayout.html.twig

   Implémente un gabarit HTML 5 de base pour Bootstrap.

   Les blocs suivants sont surchargeables :
   - title : titre de la page pour <title>
   - description : description de la page pour
     <meta name=\"description...
   - stylesheets : styles ou links pour le CSS
     déclaré dans le <head>
   - custompage_style : balise(s) <style>
     additionnelles spécifiques à chaque page
   - header : premiers éléments
     contenus dans le <div class=\"container\"> bootstrap (une row par ex.)
   - main : milieu du contenu bootstrap (deuxième row)
   - footer : fin des éléments du container bootstrap. Typiquement
     un <footer>
   - javascripts : Javascripts de fin de <body>
   - custompage_script : javascript additionnel spécifique à chaque page
#}
<!DOCTYPE HTML>
<html>
<head>
<meta charset=\"utf-8\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>{% block title %}Application Agence Voyage {% endblock %}</title>
{% block stylesheets %}
<!-- Bootstrap -->
<link rel=\"stylesheet\"\thref=\"/fonts/css/bootstrap-darkly.css\">

{% block custompage_style %}
<link href=\"/fonts/css/styles.css\" rel=\"stylesheet\">
{% endblock %}
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
          <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
          <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
        <![endif]-->
{% endblock %}
{# stylesheets #}
</head>
<body>
\t{% block body %} {# Bootstrap container #}
             <header>
\t\t{% block menu %}
\t\t\t\t{# Collect the nav links, forms, and other content for toggling #}
\t\t\t\t<nav class=\"navbar navbar-expand-md navbar-dark fixed-top bg-light\">
\t\t\t\t\t{{ knp_menu_render('main', {'currentClass': 'active'}) }}
\t\t\t\t\t{{   knp_menu_render('user', {'currentClass': 'active'}) }}
\t\t\t\t</nav>
\t\t{% endblock %} {# menu #}
             </header>

{%  block alerts %}
 {% for type, messages in app.session.flashBag.all %}
    {% for message in messages %}
        {%if type == 'error'%} {% set type = 'danger' %} {%endif%}
        {%if type == 'message'%} {% set type = 'info' %} {%endif%}
        <div class=\"alert alert-{{ type }} alert-dismissible\" role=\"alert\">
            <button type=\"button\" class=\"close\" data-dismiss=\"alert\">
                <span aria-hidden=\"true\">&times;</span>
                <span class=\"sr-only\">Close</span>
            </button>
            <p>{{ message|raw }}</p>
        </div>
    {% endfor %}
{% endfor %}
{% endblock %} {# alerts #}


\t<div style=\"min-height: 90%\" class=\"container\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-12\">
\t\t\t\t<div>
\t\t\t\t\tAgence Voyage !
\t\t\t\t</div>

\t\t\t</div>
\t\t</div>

\t\t<div class=\"container body-container\">
<main>
\t\t\t{% block main %}
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t<p>
\t\t\t\t\t\t<i> Welcome  </i>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t{% endblock %} {# main #}
</main>
\t\t</div> <!-- /.body-container -->
\t\t{% block footer %}
\t
<footer class=\"page-footer font-small blue pt-4\">

    <!-- Footer Links -->
    <div class=\"container-fluid text-center text-md-left\">

    
      <div class=\"row\">

        <div class=\"col-md-6 mt-md-0 mt-3\">

          <!-- Content -->
          <h5 class=\"text-uppercase\"> Bonne visite </h5>
          <p>Ici vous trouverez les meilleures voyages avec les meilleurs prix.</p>

        </div>
       

        <hr class=\"clearfix w-100 d-md-none pb-3\">

     
        <div class=\"col-md-3 mb-md-0 mb-3\">

            <h5 class=\"text-uppercase\"> Contactez-nous</h5>

            <ul class=\"list-unstyled\">
              <li>
                <p>(+33) 06 25 25 14 74</p>
              </li>
              <li>
                <p>5, Rue Charles Fourier,91000, EVRY</p>
              </li>
             
            </ul>

          </div>
      
      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class=\"footer-copyright text-center py-3\"> © 2018 Copyright:
    
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->

\t\t<!--  <div class=\"row\">
\t\t\t<div class=\"col-md-12\">
\t\t\t\t<footer>
\t\t\t\t\t<p > Bonne Visite </p>
\t\t\t\t</footer>
\t\t\t</div>
\t\t</div> -->
\t\t{% endblock %}{# footer #}

\t</div>
\t<!-- /.container -->
\t{% endblock %} {# body #}
</body>
{% block javascripts %}
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script\tsrc=\"../../assets/js/jquery-3.3.1.js\"></script>
<script src=\"../../assets/js/popper.js\"></script>
<script\tsrc=\"../../assets/js/bootstrap.js\"></script>
{% endblock %} {# javascripts #}
{% block custompage_script %}
{% endblock %}

</html>
", "baselayout.html.twig", "/mci/ei1619/zribi_no/CSC4101/proj-agvoy/agvoy-app-03/templates/baselayout.html.twig");
    }
}
