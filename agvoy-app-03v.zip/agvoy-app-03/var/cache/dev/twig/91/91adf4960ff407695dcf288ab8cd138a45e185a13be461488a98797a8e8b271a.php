<?php

/* frontoffice_home/show.html.twig */
class __TwigTemplate_cc608afa6d77dc4b9f34aca716ca1af5dcf34b9ec8045b4cafbdb75bd5016f62 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("baselayout.html.twig", "frontoffice_home/show.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "baselayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontoffice_home/show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontoffice_home/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Circuit";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>Circuit</h1>

";
        // line 9
        echo "\t
     <div class=\"form-horizontal\"><!-- <form>  -->
    
    \t<div class=\"form-group row\">
    \t
    \t
               <label class=\"col-sm-2 col-form-label\"> Id </label>
               \t<div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\"> ";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["circuit"]) || array_key_exists("circuit", $context) ? $context["circuit"] : (function () { throw new Twig_Error_Runtime('Variable "circuit" does not exist.', 17, $this->source); })()), "id", array()), "html", null, true);
        echo "</div>
    
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label-lg\">Description</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext form-control-lg\">";
        // line 25
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["circuit"]) || array_key_exists("circuit", $context) ? $context["circuit"] : (function () { throw new Twig_Error_Runtime('Variable "circuit" does not exist.', 25, $this->source); })()), "description", array()), "html", null, true);
        echo "</div>
            </div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Pays de Départ</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\">";
        // line 32
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["circuit"]) || array_key_exists("circuit", $context) ? $context["circuit"] : (function () { throw new Twig_Error_Runtime('Variable "circuit" does not exist.', 32, $this->source); })()), "paysDepart", array()), "html", null, true);
        echo "</div>
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Ville de départ</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\">";
        // line 39
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["circuit"]) || array_key_exists("circuit", $context) ? $context["circuit"] : (function () { throw new Twig_Error_Runtime('Variable "circuit" does not exist.', 39, $this->source); })()), "villeDepart", array()), "html", null, true);
        echo "</div>
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Ville d'arrivée</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\">";
        // line 46
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["circuit"]) || array_key_exists("circuit", $context) ? $context["circuit"] : (function () { throw new Twig_Error_Runtime('Variable "circuit" does not exist.', 46, $this->source); })()), "villeArrivee", array()), "html", null, true);
        echo "</div>
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Durée du circuit</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\">";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["circuit"]) || array_key_exists("circuit", $context) ? $context["circuit"] : (function () { throw new Twig_Error_Runtime('Variable "circuit" does not exist.', 53, $this->source); })()), "dureeCircuit", array()), "html", null, true);
        echo "</div>
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Etapes</label>
    \t\t   <div class=\"col-sm-10\">
    \t\t <table class=\"table\">
       <thead>
            <tr>
               
                <th> numero Etape</th>
                <th>ville Etape</</th>
                <th>nombreJours\t</th>
             </tr>
        </thead>
        <tbody>
                ";
        // line 70
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["circuit"]) || array_key_exists("circuit", $context) ? $context["circuit"] : (function () { throw new Twig_Error_Runtime('Variable "circuit" does not exist.', 70, $this->source); })()), "etapes", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["etape"]) {
            // line 71
            echo "            <tr>
                <td>";
            // line 72
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etape"], "numeroEtape", array()), "html", null, true);
            echo " </td>
                <td>";
            // line 73
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etape"], "villeEtape", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 74
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etape"], "nombreJours", array()), "html", null, true);
            echo "</td>
                 
            </tr>
       
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['etape'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "        </tbody>
        </table>
        </div>
    \t</div>
    \t
    \t</div> <!-- -fin !! -->
        ";
        // line 86
        echo "
    <a href=\"";
        // line 87
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("circuit_index");
        echo "\"> Retour à l'accueil</a>
    
  
                
       
  
        
        </tbody>
        </table>
        </div>
    \t</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "frontoffice_home/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  194 => 87,  191 => 86,  183 => 79,  172 => 74,  168 => 73,  164 => 72,  161 => 71,  157 => 70,  137 => 53,  127 => 46,  117 => 39,  107 => 32,  97 => 25,  86 => 17,  76 => 9,  72 => 6,  63 => 5,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'baselayout.html.twig' %}

{% block title %}Circuit{% endblock %}

{% block main %}
    <h1>Circuit</h1>

{# {{  dump(circuit)  }} #}
\t
     <div class=\"form-horizontal\"><!-- <form>  -->
    
    \t<div class=\"form-group row\">
    \t
    \t
               <label class=\"col-sm-2 col-form-label\"> Id </label>
               \t<div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\"> {{ circuit.id }}</div>
    
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label-lg\">Description</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext form-control-lg\">{{ circuit.description }}</div>
            </div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Pays de Départ</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\">{{ circuit.paysDepart}}</div>
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Ville de départ</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\">{{ circuit.villeDepart }}</div>
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Ville d'arrivée</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\">{{ circuit.villeArrivee }}</div>
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Durée du circuit</label>
                <div class=\"col-sm-10\">
    \t\t    <div class=\"form-control form-control-plaintext\">{{circuit.dureeCircuit}}</div>
    \t\t</div>
    \t</div>
    \t
    \t<div class=\"form-group row\">
    \t\t<label class=\"col-sm-2 col-form-label\">Etapes</label>
    \t\t   <div class=\"col-sm-10\">
    \t\t <table class=\"table\">
       <thead>
            <tr>
               
                <th> numero Etape</th>
                <th>ville Etape</</th>
                <th>nombreJours\t</th>
             </tr>
        </thead>
        <tbody>
                {% for etape in circuit.etapes %}
            <tr>
                <td>{{ etape.numeroEtape}} </td>
                <td>{{etape.villeEtape }}</td>
                <td>{{ etape.nombreJours }}</td>
                 
            </tr>
       
        {% endfor %}
        </tbody>
        </table>
        </div>
    \t</div>
    \t
    \t</div> <!-- -fin !! -->
        {# {{  dump(circuit)  }} #}

    <a href=\"{{ path('circuit_index') }}\"> Retour à l'accueil</a>
    
  
                
       
  
        
        </tbody>
        </table>
        </div>
    \t</div>

{% endblock %}", "frontoffice_home/show.html.twig", "/mci/ei1619/zribi_no/CSC4101/proj-agvoy/agvoy-app-03/templates/frontoffice_home/show.html.twig");
    }
}
